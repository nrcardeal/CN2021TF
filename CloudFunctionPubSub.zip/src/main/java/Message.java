import java.util.Map;

public class Message {
    String data;
    Map<String, String> attributes;
    String messageId;
    String publishTime;
}
